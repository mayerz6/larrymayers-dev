
class Msg{

constructor(){

}

}

new Msg();

